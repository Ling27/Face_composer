import os
import cv2
from glob import glob
import copy, random
import numpy as np

#list1
# label_list = ['skin', 'neck', 'hat', 'eye_g', 'hair', 'ear_r', 'neck_l', 'cloth', 'l_eye', 'r_eye', 'l_brow', 'r_brow', 'nose', 'l_ear', 'r_ear', 'mouth', 'u_lip', 'l_lip']
#list2
# label_list = ['skin', 'nose', 'eye_g', 'l_eye', 'r_eye', 'l_brow', 'r_brow', 'l_ear', 'r_ear', 'mouth', 'u_lip', 'l_lip', 'hair', 'hat', 'ear_r', 'neck_l', 'neck', 'cloth']

src_img_path = 'CelebA-HQ-img'
src_mask_path = 'CelebAMask-HQ-mask-anno/*'
out_path = 'outputs'
os.makedirs(out_path, exist_ok=True)

def parts_composition(src_id, tgt_id, target_region, save_img=True):
    src_img = cv2.imread(os.path.join(src_img_path, f'{src_id}.jpg'))
    src_maskprefix = str(src_id).zfill(5)
    for each_region in target_region:
        src_mask_p = glob(os.path.join(src_mask_path, f'{src_maskprefix}_{each_region}.png'))[0]
        src_mask_ = cv2.imread(src_mask_p, cv2.IMREAD_GRAYSCALE)
        if "src_mask" in locals():
            src_mask += src_mask_
        else:
            src_mask = src_mask_
    if src_img.shape[:2] != src_mask.shape[:2]:
        src_img = cv2.resize(src_img, (src_mask.shape[1], src_mask.shape[0]))

    tgt_img = cv2.imread(os.path.join(src_img_path, f'{tgt_id}.jpg'))
    tgt_maskprefix = str(tgt_id).zfill(5)
    for each_region in target_region:
        tgt_mask_p = glob(os.path.join(src_mask_path, f'{tgt_maskprefix}_{each_region}.png'))[0]
        tgt_mask_ = cv2.imread(tgt_mask_p, cv2.IMREAD_GRAYSCALE)
        if "tgt_mask" in locals():
            tgt_mask += tgt_mask_
        else:
            tgt_mask = tgt_mask_
    if tgt_img.shape[:2] != tgt_mask.shape[:2]:
        tgt_img = cv2.resize(tgt_img, (tgt_mask.shape[1], tgt_mask.shape[0]))

    union_mask = src_mask + tgt_mask
    union_mask = union_mask > 0
    # src_mask = src_mask > 0
    # tgt_mask = tgt_mask > 0

    composed_tgt = copy.deepcopy(tgt_img)
    composed_tgt[union_mask] = src_img[union_mask]

    if save_img:
        tgt_regions = "_".join(target_region)
        cv2.imwrite(os.path.join(out_path, f'{tgt_id}_{tgt_regions}_0original.jpg'), tgt_img)
        cv2.imwrite(os.path.join(out_path, f'{tgt_id}_{tgt_regions}_2composed.jpg'), composed_tgt)
        cv2.imwrite(os.path.join(out_path, f'{tgt_id}_{tgt_regions}_3ref.jpg'), src_img)
        mask = (union_mask * 255).astype(np.uint8)
        cv2.imwrite(os.path.join(out_path, f'{tgt_id}_{tgt_regions}_1mask.jpg'), mask)
    return composed_tgt, tgt_img, src_img

label_list = ['l_eye', 'r_eye', 'l_brow', 'r_brow', 'nose', 'mouth', 'u_lip', 'l_lip'] #'skin', 'neck', 'hat', 'hair',

def get_regions(idx_list):
    temp_list = []
    for idx in idx_list:
        temp_list.append(label_list[idx])
    return temp_list

parts_composition(1, 4, get_regions(random.sample(range(0, len(label_list)), 3)))
parts_composition(1, 4, get_regions(random.sample(range(0, len(label_list)), 4)))
parts_composition(1, 4, get_regions(random.sample(range(0, len(label_list)), 2)))
parts_composition(1, 4, get_regions(random.sample(range(0, len(label_list)), 6)))




# img1 = cv2.imread(os.path.join(src_img_path, f'{id1}.jpg'))
# img2 = cv2.imread(os.path.join(src_img_path, f'{id2}.jpg'))
# img1 = cv2.resize(img1, (512, 512))
# img2 = cv2.resize(img2, (512, 512))
#
# target_region = 'l_brow'
# mask1_prefix = str(id1).zfill(5)
# mask1_p = glob(os.path.join(src_mask_path, f'{mask1_prefix}_{target_region}.png'))[0]
# mask1 = cv2.imread(mask1_p, cv2.IMREAD_GRAYSCALE)
# cv2.imwrite('1_mask.jpg', mask1)
#
# mask2_prefix = str(id2).zfill(5)
# mask2_p = glob(os.path.join(src_mask_path, f'{mask2_prefix}_{target_region}.png'))[0]
# mask2 = cv2.imread(mask2_p, cv2.IMREAD_GRAYSCALE)
# cv2.imwrite('2_mask.jpg', mask2)
#
# full_mask = mask1 + mask2
# full_mask = full_mask > 0
# mask1 = mask1 > 0
# mask2 = mask2 > 0

# num_steps = 10  # Number of intermediate steps
# for i in range(num_steps + 1):
#     alpha = i / num_steps  # Blending factor
#     morphed_mask = cv2.addWeighted(mask1, 1 - alpha, mask2, alpha, 0)
#     cv2.imwrite(f'morphed_mask_{i}.png', morphed_mask)


# img1_modified = copy.deepcopy(img1)
# img2_modified = copy.deepcopy(img2)
# img1_modified2 = copy.deepcopy(img1)
# img2_modified2 = copy.deepcopy(img2)
# img1_modified3 = copy.deepcopy(img1)
# img2_modified3 = copy.deepcopy(img2)
#
# img1_modified[mask1] = img2[mask1]
# img1_modified2[mask2] = img2[mask2]
# img1_modified3[full_mask] = img2[full_mask]
#
# img2_modified[mask1] = img1[mask1]
# img2_modified2[mask2] = img1[mask2]
# img2_modified3[full_mask] = img1[full_mask]
#
# cv2.imwrite('1.jpg', img1)
# cv2.imwrite('1_mask1.jpg', img1_modified)
# cv2.imwrite('1_mask2.jpg', img1_modified2)
# cv2.imwrite('1_mask3.jpg', img1_modified3)
#
# cv2.imwrite('2.jpg', img2)
# cv2.imwrite('2_mask1.jpg', img2_modified)
# cv2.imwrite('2_mask2.jpg', img2_modified2)
# cv2.imwrite('2_mask3.jpg', img2_modified3)

print('finish')


